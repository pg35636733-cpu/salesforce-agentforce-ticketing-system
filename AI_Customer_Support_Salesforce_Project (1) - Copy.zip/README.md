# AI-Powered Customer Support Ticketing System (Salesforce)

A beginner-friendly Salesforce DX starter project. It uses the standard **Case** object as the ticket record and adds a small set of custom fields plus a validation rule. Agentforce must be configured and tested separately in an org that supports it.

## Included deployable metadata

- `Case.Issue_Category__c` — category picklist
- `Case.AI_Summary__c` — field to store an AI-generated summary
- `Case.AI_Suggested_Response__c` — field to store a proposed customer reply
- `Case.AI_Processed__c` — checkbox to track processing
- `Case.Resolution_Notes__c` — resolution notes
- `Case.Require_Resolution_Notes_When_Closed` — prevents closing a case without resolution notes

These fields do not generate AI by themselves. The AI fields are storage locations until connected to a Flow, prompt template, or Agentforce action.

## Option A — Deploy with Salesforce CLI

Prerequisites:
1. Create a Salesforce Developer Edition org. For Agentforce, use Salesforce's Agentforce Developer Edition signup path from the official Trailhead guide: https://trailhead.salesforce.com/content/learn/projects/create-an-agent-using-pro-code-tools/get-started-with-agentforce
2. Install Salesforce CLI: https://developer.salesforce.com/tools/salesforcecli
3. Unzip this project and open a terminal in this folder.

Commands:

```bash
sf org login web --alias support-dev --instance-url https://login.salesforce.com
sf project deploy start --manifest force-app/main/default/package.xml --target-org support-dev
```

For a sandbox, use `https://test.salesforce.com` for the login URL. Review the deployment output; if your org's API version is lower than 66.0, update `sourceApiVersion` and the package version to an API version supported by that org.

## Option B — Use Setup manually

You can create the same fields through **Setup → Object Manager → Case → Fields & Relationships → New**. Create each field using the names, types, and picklist values shown in the XML files. Then create the validation rule described below.

Validation rule:
```text
AND(
    ISPICKVAL(Status, "Closed"),
    ISBLANK(Resolution_Notes__c)
)
```
Error message: `Please enter Resolution Notes before closing this case.`

## Next configuration steps in Salesforce

### 1. App
Setup → App Manager → New Lightning App.
- App label: `AI Customer Support`
- Add navigation items: Cases, Contacts, Accounts, Reports, Dashboards.
- Assign access to your admin/support profiles as appropriate.

### 2. Queues
Setup → Queues → New:
- `Billing Support` (label) / `Billing_Support` (developer name)
- `Technical Support` / `Technical_Support`
Add Case as a supported object and add appropriate members.

### 3. Record-triggered Flow: assign by category
Setup → Flows → New Flow → Record-Triggered Flow.
- Object: Case
- Trigger: A record is created or updated
- Entry condition: `Issue_Category__c Is Null = False`
- Optimize for: Actions and Related Records
- Add a Decision element with outcomes:
  - Billing: `Issue_Category__c Equals Billing`
  - Technical: `Issue_Category__c Equals Technical Issue`
  - Account Access: `Issue_Category__c Equals Account Access`
- For each outcome, use an Update Records element to set OwnerId to the corresponding queue's ID. Obtain queue IDs from the queue record in Setup or use a Get Records element on Group where Type = Queue and DeveloperName matches.
- Add a default path that leaves the owner unchanged.
- Save as `Assign_Case_By_Category`, test with sample cases, then activate.

Important: If using a Get Records element for Group, store the first matching record and use its Id. Confirm the queue supports Cases and exists before activating the flow.

### 4. Record-triggered Flow: flag high-priority cases
Create a second Case record-triggered flow:
- Trigger: record created or updated
- Decision: `Priority Equals High`
- Action: send an email alert or create a task for the support team, using an email alert/template configured in Setup.
- Avoid updating the same triggering Case unnecessarily, to prevent flow recursion.
- Test before activation.

### 5. Agentforce setup
In an Agentforce-enabled org:
- Confirm Einstein Generative AI / Agentforce prerequisites and required permissions.
- Setup → Agentforce Agents (menu labels may vary) → create a new agent.
- Start with a service/support agent template if offered.
- Provide clear instructions: answer only from approved Knowledge content; do not invent policy or order details; ask clarifying questions; hand off unresolved or sensitive issues to a human.
- Add only actions available in the org, such as approved Knowledge search or Case lookup/update actions.
- Test in preview with both known FAQs and unknown questions.
- Do not allow the agent to close or modify records unless the action, permissions, and confirmation behavior are configured and tested.

Official guidance: https://help.salesforce.com/s/articleView?id=ai.agent_setup_enable.htm&language=en_US&type=5

### 6. Reports
Create reports using Cases:
- Open Cases: Status not equal to Closed
- High-Priority Cases: Priority equals High and Status not equal to Closed
- Cases by Category: group by Issue Category
- Cases by Owner: group by Case Owner
Add charts to a dashboard called `Customer Support Overview`.

## Test checklist

- [ ] Create a Case with category Billing.
- [ ] Confirm the Issue Category field saves correctly.
- [ ] Attempt to close a Case without Resolution Notes; it should show the validation error.
- [ ] Add Resolution Notes and close the Case; it should save.
- [ ] Verify the assignment Flow routes the Case to the expected queue.
- [ ] Verify high-priority notification behavior in a test inbox.
- [ ] Test Agentforce with a known FAQ and an unknown question.
- [ ] Confirm the agent does not claim an action succeeded when it did not.
- [ ] Verify that support users only have access to the records and actions they need.

## Security notes

Use synthetic customer data while learning. Do not place real customer secrets or sensitive personal information in sample Cases. Review profile/permission-set access to all custom fields and agent actions before presenting or deploying this project.
